"""
main.py - AI Student Study Timetable Generator (Tkinter GUI)
------------------------------------------------------------
Flow: Student input -> GUI -> validation -> days calculation ->
      knowledge base + IF-THEN rule engine (rules.py) ->
      schedule generator (scheduler.py) -> timetable window.
Run with:  python main.py
"""
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, datetime

import rules
import scheduler

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data.json")
DIFFICULTY_LEVELS = ["Easy", "Medium", "Hard"]
PREPARATION_LEVELS = ["Low", "Medium", "High"]


# ---------------------------------------------------------------------------
# DATA FILE HELPERS (data.json)
# ---------------------------------------------------------------------------
def read_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def write_data(data):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except OSError:
        pass  # saving is optional; never crash because of it


# ---------------------------------------------------------------------------
# MAIN APPLICATION WINDOW
# ---------------------------------------------------------------------------
class StudyTimetableApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Student Study Timetable Generator")
        self.root.geometry("760x620")
        self.root.minsize(700, 580)
        self.subjects = []            # list of subject dictionaries

        rules.load_rules_from_file(DATA_FILE)
        self.build_ui()
        self.load_saved_data()

    # ------------------------- GUI LAYOUT -------------------------------
    def build_ui(self):
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"))
        ttk.Label(self.root, text="AI Student Study Timetable Generator",
                  style="Title.TLabel").pack(pady=(12, 6))

        # --- Student information frame ---
        student = ttk.LabelFrame(self.root, text="Student Information", padding=10)
        student.pack(fill="x", padx=15, pady=5)
        self.name_var = tk.StringVar()
        self.hours_var = tk.StringVar(value="4")
        self.start_var = tk.StringVar(value="18:00")
        ttk.Label(student, text="Student Name:").grid(row=0, column=0, sticky="w", pady=3)
        ttk.Entry(student, textvariable=self.name_var, width=28).grid(row=0, column=1, padx=8)
        ttk.Label(student, text="Study Hours / Day:").grid(row=0, column=2, sticky="w")
        ttk.Entry(student, textvariable=self.hours_var, width=8).grid(row=0, column=3, padx=8)
        ttk.Label(student, text="Start Time (HH:MM):").grid(row=0, column=4, sticky="w")
        ttk.Entry(student, textvariable=self.start_var, width=8).grid(row=0, column=5, padx=8)

        # --- Subject information frame ---
        subj = ttk.LabelFrame(self.root, text="Subject Information", padding=10)
        subj.pack(fill="x", padx=15, pady=5)
        self.subject_var = tk.StringVar()
        self.exam_var = tk.StringVar()
        self.diff_var = tk.StringVar()
        self.prep_var = tk.StringVar()
        ttk.Label(subj, text="Subject Name:").grid(row=0, column=0, sticky="w", pady=3)
        ttk.Entry(subj, textvariable=self.subject_var, width=28).grid(row=0, column=1, padx=8)
        ttk.Label(subj, text="Exam Date (DD-MM-YYYY):").grid(row=0, column=2, sticky="w")
        ttk.Entry(subj, textvariable=self.exam_var, width=14).grid(row=0, column=3, padx=8)
        ttk.Label(subj, text="Difficulty:").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Combobox(subj, textvariable=self.diff_var, values=DIFFICULTY_LEVELS,
                     state="readonly", width=25).grid(row=1, column=1, padx=8)
        ttk.Label(subj, text="Preparation Level:").grid(row=1, column=2, sticky="w")
        ttk.Combobox(subj, textvariable=self.prep_var, values=PREPARATION_LEVELS,
                     state="readonly", width=11).grid(row=1, column=3, padx=8)

        # --- Buttons ---
        buttons = ttk.Frame(self.root)
        buttons.pack(pady=8)
        for text, command in [("Add Subject", self.add_subject),
                              ("Remove Subject", self.remove_subject),
                              ("Clear", self.clear_all),
                              ("Generate Timetable", self.generate),
                              ("Exit", self.root.destroy)]:
            ttk.Button(buttons, text=text, command=command).pack(side="left", padx=5)

        # --- Subject list (Treeview + scrollbar) ---
        listing = ttk.LabelFrame(self.root, text="Subject List", padding=8)
        listing.pack(fill="both", expand=True, padx=15, pady=(5, 12))
        columns = ("Subject", "Exam Date", "Difficulty", "Preparation")
        self.tree = ttk.Treeview(listing, columns=columns, show="headings", height=8)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=150, anchor="center")
        self.tree.column("Subject", width=250, anchor="w")
        scroll = ttk.Scrollbar(listing, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    # ------------------------- INPUT VALIDATION -------------------------
    def validate_subject_inputs(self):
        """Validate one subject entry. Returns a dict or None (after showing an error)."""
        name = self.subject_var.get().strip()
        if not name:
            return self.error("Subject name must not be empty.")
        if any(s["name"].lower() == name.lower() for s in self.subjects):
            return self.error(f"'{name}' is already in the list (duplicate subject).")
        try:
            exam = rules.parse_date(self.exam_var.get())
        except ValueError:
            return self.error("Exam date is invalid.\nUse the format DD-MM-YYYY, e.g. 10-10-2026.")
        days_left = rules.days_remaining(exam)
        if days_left < 0:
            return self.error("Exam date is in the past. Please enter a future date.")
        if days_left == 0:
            return self.error("The exam is today - there are no study days left.\n"
                              "Please enter an exam date from tomorrow onwards.")
        if self.diff_var.get() not in DIFFICULTY_LEVELS:
            return self.error("Please select a difficulty level.")
        if self.prep_var.get() not in PREPARATION_LEVELS:
            return self.error("Please select a preparation level.")
        return {"name": name, "exam_date": exam.strftime(rules.DATE_FORMAT),
                "difficulty": self.diff_var.get(), "preparation": self.prep_var.get()}

    def validate_student_inputs(self):
        """Validate name, daily hours and start time. Returns (name, hours, start) or None."""
        name = self.name_var.get().strip()
        if not name:
            return self.error("Student name must not be empty.")
        try:
            hours = float(self.hours_var.get())
        except ValueError:
            return self.error("Study hours must be a number, e.g. 4 or 2.5.")
        limit = rules.RULES["max_daily_hours"]
        if hours <= 0:
            return self.error("Study hours must be greater than 0.")
        if hours * 60 < rules.RULES["block_minutes"]:
            return self.error("Insufficient study time: at least 15 minutes per day is needed.")
        if hours > limit:
            return self.error(f"Study hours per day cannot exceed {limit}. Please be realistic!")
        try:
            datetime.strptime(self.start_var.get().strip(), "%H:%M")
        except ValueError:
            return self.error("Start time is invalid. Use 24-hour HH:MM, e.g. 18:00.")
        return name, hours, self.start_var.get().strip()

    def error(self, message):
        messagebox.showerror("Invalid Input", message)
        return None

    # ------------------------- BUTTON FUNCTIONS -------------------------
    def add_subject(self):
        subject = self.validate_subject_inputs()
        if subject is None:
            return
        self.subjects.append(subject)
        self.refresh_table()
        # clear only the subject fields so the next one can be typed quickly
        self.subject_var.set("")
        self.exam_var.set("")
        self.diff_var.set("")
        self.prep_var.set("")

    def remove_subject(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Remove Subject", "Please select a subject in the list first.")
            return
        names = {self.tree.item(i, "values")[0] for i in selected}
        self.subjects = [s for s in self.subjects if s["name"] not in names]
        self.refresh_table()

    def clear_all(self):
        if self.subjects and not messagebox.askyesno("Clear", "Remove all subjects and clear the form?"):
            return
        self.subjects = []
        for var in (self.subject_var, self.exam_var, self.diff_var, self.prep_var):
            var.set("")
        self.refresh_table()

    def refresh_table(self):
        self.tree.delete(*self.tree.get_children())
        for s in self.subjects:
            self.tree.insert("", "end", values=(s["name"], s["exam_date"],
                                                s["difficulty"], s["preparation"]))

    def load_saved_data(self):
        """Load student name, hours and still-valid subjects from data.json."""
        data = read_data()
        self.name_var.set(data.get("student_name", ""))
        self.hours_var.set(str(data.get("daily_hours", 4)))
        self.start_var.set(data.get("start_time", "18:00"))
        for s in data.get("subjects", []):
            try:
                valid = (rules.days_remaining(rules.parse_date(s["exam_date"])) > 0
                         and s["difficulty"] in DIFFICULTY_LEVELS
                         and s["preparation"] in PREPARATION_LEVELS and s["name"].strip())
            except (ValueError, KeyError, AttributeError, TypeError):
                valid = False
            if valid:                       # skip expired / corrupt entries
                self.subjects.append(s)
        self.refresh_table()

    # ------------------------- GENERATE TIMETABLE -----------------------
    def generate(self):
        if not self.subjects:
            messagebox.showwarning("No Subjects", "Please add at least one subject first.")
            return
        student = self.validate_student_inputs()
        if student is None:
            return
        name, hours, start = student

        # Re-check that no saved exam date has passed in the meantime
        today_subjects = [s for s in self.subjects
                          if rules.days_remaining(rules.parse_date(s["exam_date"])) > 0]
        if len(today_subjects) != len(self.subjects):
            messagebox.showwarning("Expired Subjects", "Some exams are no longer in the future "
                                   "and were skipped.")
        if not today_subjects:
            return

        try:
            analysis = rules.evaluate_all(today_subjects)             # AI rule engine
            rows, warnings = scheduler.generate_timetable(today_subjects, hours, start)
        except Exception as exc:                                       # never crash the GUI
            messagebox.showerror("Error", f"Could not generate the timetable:\n{exc}")
            return
        if not rows:
            messagebox.showwarning("Insufficient Time",
                                   "No study sessions fit. Try more hours or an earlier start time.")
            return

        write_data({"student_name": name, "daily_hours": hours, "start_time": start,
                    "subjects": self.subjects, "rules": rules.RULES, "timetable": rows})
        if warnings:
            extra = "\n...and more." if len(warnings) > 6 else ""
            messagebox.showwarning("Insufficient Study Time", "\n".join(warnings[:6]) + extra)
        TimetableWindow(self.root, name, rows, analysis, warnings)


# ---------------------------------------------------------------------------
# TIMETABLE WINDOW
# ---------------------------------------------------------------------------
class TimetableWindow:
    def __init__(self, parent, student_name, rows, analysis, warnings):
        win = tk.Toplevel(parent)
        win.title("Generated Study Timetable")
        win.geometry("900x580")
        ttk.Label(win, text=f"Student: {student_name}",
                  font=("Segoe UI", 14, "bold")).pack(pady=(10, 0))
        ttk.Label(win, text=f"Generated on {date.today().strftime(rules.DATE_FORMAT)}").pack()

        notebook = ttk.Notebook(win)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)
        self.build_timetable_tab(notebook, rows)
        self.build_analysis_tab(notebook, analysis, warnings)
        ttk.Button(win, text="Close", command=win.destroy).pack(pady=(0, 10))

    def build_timetable_tab(self, notebook, rows):
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="Study Timetable")
        columns = ("Date", "Day", "Time", "Subject", "Duration", "Priority")
        tree = ttk.Treeview(tab, columns=columns, show="headings")
        widths = (95, 90, 180, 240, 80, 80)
        for col, width in zip(columns, widths):
            tree.heading(col, text=col)
            tree.column(col, width=width, anchor="w" if col == "Subject" else "center")
        # colour rows by priority so the table is easy to scan
        tree.tag_configure("High", background="#ffd6d6")
        tree.tag_configure("Medium", background="#fff3c4")
        tree.tag_configure("Low", background="#d9f2d9")
        tree.tag_configure("break", background="#eeeeee", foreground="#777777")
        for r in rows:
            tag = "break" if r["kind"] == "break" else r["priority"]
            tree.insert("", "end", tags=(tag,), values=(r["date"], r["day"], r["time"],
                                                       r["subject"], r["duration"], r["priority"]))
        ys = ttk.Scrollbar(tab, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=ys.set)
        tree.pack(side="left", fill="both", expand=True)
        ys.pack(side="right", fill="y")

    def build_analysis_tab(self, notebook, analysis, warnings):
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="Priority Analysis")
        columns = ("Subject", "Difficulty Score", "Preparation Score",
                   "Exam Proximity Score", "Total Score", "Priority Level")
        tree = ttk.Treeview(tab, columns=columns, show="headings", height=6)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=130, anchor="center")
        tree.column("Subject", width=200, anchor="w")
        for r in analysis:
            tree.insert("", "end", values=(r["name"], r["difficulty_score"], r["preparation_score"],
                                           r["proximity_score"], r["total"], r["level"]))
        tree.pack(fill="x", padx=5, pady=5)

        ttk.Label(tab, text="Why each subject got its priority (today's reasoning):").pack(anchor="w", padx=5)
        frame = ttk.Frame(tab)
        frame.pack(fill="both", expand=True, padx=5, pady=5)
        text = tk.Text(frame, wrap="word", height=10, font=("Consolas", 10))
        ys = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=ys.set)
        text.pack(side="left", fill="both", expand=True)
        ys.pack(side="right", fill="y")
        text.insert("end", "\n\n".join(rules.explain(r) for r in analysis))
        text.insert("end", "\n\nNote: priorities are recalculated every day, so a subject's "
                           "study time grows as its exam gets closer.")
        if warnings:
            text.insert("end", "\n\nWARNINGS:\n" + "\n".join(warnings))
        text.configure(state="disabled")


if __name__ == "__main__":
    root = tk.Tk()
    StudyTimetableApp(root)
    root.mainloop()
