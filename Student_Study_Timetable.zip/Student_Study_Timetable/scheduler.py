"""
scheduler.py - Study-time allocation + timetable (schedule) generator
---------------------------------------------------------------------
Steps for every study day:
  1. Keep only subjects whose exam is still in the future.
  2. Re-calculate priorities with the rule engine (urgency changes daily).
  3. Split the daily study minutes between subjects by priority score.
  4. Place sessions one after another (no overlap) and add breaks.
"""
from datetime import date, timedelta
import rules


def format_time(minutes):
    """Minutes since midnight -> '6:30 PM'."""
    hour, minute = divmod(minutes, 60)
    suffix = "AM" if hour < 12 else "PM"
    return f"{hour % 12 or 12}:{minute:02d} {suffix}"


def allocate_minutes(evaluated, total_minutes):
    """
    Divide total_minutes among subjects in proportion to their priority score.
    Works in blocks (default 15 min). Every subject gets at least one block
    if there is room; if not, only the highest-priority subjects are studied.
    Returns (dict {subject name: minutes}, list of dropped subject names).
    """
    block = rules.RULES["block_minutes"]
    blocks = total_minutes // block
    ordered = sorted(evaluated, key=lambda r: (-r["total"], r["exam_date"]))

    dropped = []
    if blocks < len(ordered):                    # not enough time for everyone
        dropped = [r["name"] for r in ordered[blocks:]]
        ordered = ordered[:blocks]

    # Rule: every remaining subject gets 1 block, extra blocks go by priority
    share = {r["name"]: 1 for r in ordered}
    extra = blocks - len(ordered)
    weight_sum = sum(r["total"] for r in ordered) or 1
    fractions = []
    for r in ordered:
        exact = extra * r["total"] / weight_sum
        share[r["name"]] += int(exact)
        fractions.append((exact - int(exact), r["name"]))
    leftover = blocks - sum(share.values())
    for _, name in sorted(fractions, reverse=True)[:leftover]:
        share[name] += 1                         # largest-remainder rounding

    return {name: count * block for name, count in share.items()}, dropped


def break_length(session_minutes):
    """Longer sessions get a longer break (breaks are not study time)."""
    if session_minutes >= rules.RULES["long_session_minutes"]:
        return rules.RULES["long_break_minutes"]
    return rules.RULES["short_break_minutes"]


def build_day(day, evaluated, daily_hours, start_minutes):
    """Create the timetable rows for a single day. Returns (rows, warnings)."""
    rows, warnings = [], []
    total = int(daily_hours * 60) // rules.RULES["block_minutes"] * rules.RULES["block_minutes"]
    minutes_map, dropped = allocate_minutes(evaluated, total)
    date_text = day.strftime(rules.DATE_FORMAT)
    if dropped:
        warnings.append(f"{date_text}: not enough study time for {', '.join(dropped)}.")

    # Sort subjects by priority, highest first
    by_name = {r["name"]: r for r in evaluated}
    plan = sorted(minutes_map.items(), key=lambda kv: (-by_name[kv[0]]["total"], by_name[kv[0]]["exam_date"]))

    cursor, last_minute_of_day = start_minutes, 24 * 60 - 1
    for index, (name, mins) in enumerate(plan):
        gap = break_length(plan[index - 1][1]) if index > 0 else 0
        if cursor + gap + mins > last_minute_of_day:   # would run past midnight
            warnings.append(f"{date_text}: {name} does not fit before midnight.")
            break
        if gap:                                        # add break before this session
            rows.append(make_row(day, cursor, cursor + gap, "Break", gap, "-", "break"))
            cursor += gap
        rows.append(make_row(day, cursor, cursor + mins, name, mins, by_name[name]["level"], "study"))
        cursor += mins
    return rows, warnings


def make_row(day, start, end, subject, minutes, level, kind):
    return {
        "date": day.strftime(rules.DATE_FORMAT),
        "day": day.strftime("%A"),
        "time": f"{format_time(start)} – {format_time(end)}",
        "subject": subject,
        "duration": f"{minutes} min",
        "priority": level,
        "kind": kind,
    }


def generate_timetable(subjects, daily_hours, start_time="18:00", start_date=None):
    """
    Main entry point.
    subjects: list of dicts (name, exam_date, difficulty, preparation)
    Returns (rows, warnings). Never schedules on or after an exam date.
    """
    start_date = start_date or date.today()
    hour, minute = map(int, start_time.split(":"))
    start_minutes = hour * 60 + minute

    last_exam = max(rules.parse_date(s["exam_date"]) for s in subjects)
    num_days = min((last_exam - start_date).days, rules.RULES["max_plan_days"])

    rows, warnings = [], []
    for offset in range(num_days):
        day = start_date + timedelta(days=offset)
        # Only subjects whose exam is after this day
        active = [s for s in subjects if rules.parse_date(s["exam_date"]) > day]
        if not active:
            continue
        evaluated = rules.evaluate_all(active, today=day)   # priority changes daily
        day_rows, day_warnings = build_day(day, evaluated, daily_hours, start_minutes)
        rows += day_rows
        warnings += day_warnings
    return rows, warnings
