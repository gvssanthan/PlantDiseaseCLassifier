"""
rules.py - Knowledge Base + IF-THEN AI Rule Engine
--------------------------------------------------
Holds all configurable rules (the knowledge base) and the functions that
apply IF-THEN rules to calculate and EXPLAIN every subject's priority.
No machine learning is used - only simple, readable rules.
"""
import json
from datetime import datetime, date

DATE_FORMAT = "%d-%m-%Y"

# ---------------------------------------------------------------------------
# KNOWLEDGE BASE  (all values are configurable; data.json can override them)
# ---------------------------------------------------------------------------
RULES = {
    # Rule group 1: subject difficulty -> points
    "difficulty_scores": {"Easy": 1, "Medium": 2, "Hard": 3},
    # Rule group 2: preparation level -> points (low preparation = more points)
    "preparation_scores": {"High": 1, "Medium": 2, "Low": 3},
    # Rule group 3: exam proximity. (days_limit, points) - checked in order
    "proximity_rules": [[3, 4], [7, 3], [15, 2]],
    "proximity_default": 1,            # exam is more than 15 days away
    # Priority level thresholds on the total score (max possible = 10)
    "level_thresholds": {"high": 8, "medium": 5},
    # Scheduling settings
    "max_daily_hours": 12,             # reasonable daily study limit
    "max_plan_days": 14,               # plan at most this many days ahead
    "block_minutes": 15,               # smallest study slot
    "long_session_minutes": 60,        # session >= this gets a long break
    "long_break_minutes": 15,
    "short_break_minutes": 5,
}


def load_rules_from_file(path):
    """Override default rules with the 'rules' section of data.json (if valid)."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            saved = json.load(f).get("rules", {})
        for key, value in saved.items():
            if key in RULES and type(value) is type(RULES[key]):
                RULES[key] = value
    except (OSError, ValueError, AttributeError):
        pass  # missing/corrupt file -> keep defaults


# ---------------------------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------------------------
def parse_date(text):
    """Convert 'DD-MM-YYYY' text to a date. Raises ValueError if invalid."""
    return datetime.strptime(text.strip(), DATE_FORMAT).date()


def days_remaining(exam_date, today=None):
    """Number of days between today and the exam date."""
    today = today or date.today()
    return (exam_date - today).days


# ---------------------------------------------------------------------------
# IF-THEN RULES (each returns: points, explanation text)
# ---------------------------------------------------------------------------
def rule_difficulty(difficulty):
    # IF difficulty = Hard THEN +3 ; Medium THEN +2 ; Easy THEN +1
    points = RULES["difficulty_scores"][difficulty]
    return points, f"Difficulty: {difficulty} → +{points}"


def rule_preparation(preparation):
    # IF preparation = Low THEN +3 ; Medium THEN +2 ; High THEN +1
    points = RULES["preparation_scores"][preparation]
    return points, f"Preparation: {preparation} → +{points}"


def rule_proximity(days_left):
    # IF exam within 3 days THEN +4 ; within 7 THEN +3 ; within 15 THEN +2 ; else +1
    for limit, points in RULES["proximity_rules"]:
        if days_left <= limit:
            return points, f"Exam in {days_left} day(s) (within {limit} days) → +{points}"
    points = RULES["proximity_default"]
    last = RULES["proximity_rules"][-1][0]
    return points, f"Exam in {days_left} day(s) (more than {last} days) → +{points}"


def classify_priority(total):
    # IF total >= 8 THEN High ; IF total >= 5 THEN Medium ; ELSE Low
    if total >= RULES["level_thresholds"]["high"]:
        return "High"
    if total >= RULES["level_thresholds"]["medium"]:
        return "Medium"
    return "Low"


# ---------------------------------------------------------------------------
# AI RULE ENGINE
# ---------------------------------------------------------------------------
def evaluate_subject(subject, today=None):
    """
    Apply all IF-THEN rules to one subject.
    subject: dict with name, exam_date (DD-MM-YYYY), difficulty, preparation.
    Returns a dict with every score, the total, the level and the reasons.
    """
    exam = parse_date(subject["exam_date"])
    days_left = days_remaining(exam, today)

    d_pts, d_why = rule_difficulty(subject["difficulty"])
    p_pts, p_why = rule_preparation(subject["preparation"])
    e_pts, e_why = rule_proximity(days_left)

    total = d_pts + p_pts + e_pts          # Final Priority formula
    return {
        "name": subject["name"],
        "exam_date": exam,
        "days_left": days_left,
        "difficulty": subject["difficulty"],
        "preparation": subject["preparation"],
        "difficulty_score": d_pts,
        "preparation_score": p_pts,
        "proximity_score": e_pts,
        "total": total,
        "level": classify_priority(total),
        "reasons": [d_why, p_why, e_why],
    }


def evaluate_all(subjects, today=None):
    """Evaluate every subject and sort by priority (highest first, then earliest exam)."""
    results = [evaluate_subject(s, today) for s in subjects]
    results.sort(key=lambda r: (-r["total"], r["exam_date"]))
    return results


def explain(result):
    """Human-readable explanation of one subject's priority."""
    lines = [f"{result['name']}:"]
    lines += [f"   {r}" for r in result["reasons"]]
    lines.append(f"   Total Priority = {result['total']}")
    lines.append(f"   Priority Level = {result['level']}")
    return "\n".join(lines)
