# AI Student Study Timetable Generator

## Objective
A desktop application (Python + Tkinter) that takes a student's subjects, exam dates,
difficulty, preparation level and daily study hours, and automatically builds a
personalised study timetable using a **rule-based AI (IF–THEN rules)**. No machine learning.

## Features
- Multiple subjects, shown in a Treeview table
- Full input validation with friendly message boxes
- Explainable priority score for every subject
- Study time split by priority, in 15-minute blocks
- Automatic breaks (long session = 15 min, short = 5 min; configurable)
- No overlapping sessions, nothing scheduled on/after an exam date
- Priorities recalculated daily (exam gets closer = more time)
- Timetable + Priority Analysis window; results saved to `data.json`

## Technologies
Python 3.8+, Tkinter / ttk (built in), `json`, `datetime`. No external libraries.

## Installation
1. Install Python 3 from python.org (tick "Add Python to PATH"; Tkinter is included).
   On Ubuntu/Debian: `sudo apt install python3-tk`.
2. Extract the project folder `Student_Study_Timetable`.

## How to Run
```
cd Student_Study_Timetable
python main.py
```
(VS Code: File → Open Folder → open `main.py` → press ▶ Run, or `python main.py` in the terminal.)

## How the AI Rules Work
Final Priority = Difficulty score + Preparation score + Exam-proximity score

| Rule | Points |
|------|--------|
| Difficulty Easy / Medium / Hard | 1 / 2 / 3 |
| Preparation High / Medium / Low | 1 / 2 / 3 |
| Exam within 3 days / 7 / 15 / more | 4 / 3 / 2 / 1 |

Level: total ≥ 8 → **High**, ≥ 5 → **Medium**, otherwise **Low**.
All values live in `RULES` (rules.py) and can be overridden in `data.json`.

Study time: each subject gets one 15-minute block, then the remaining blocks are
shared in proportion to priority scores. If there are more subjects than blocks,
only the highest-priority subjects are scheduled that day (with a warning).

## Files
- `main.py` – GUI, validation, buttons, timetable display
- `rules.py` – knowledge base, IF–THEN rules, priority calculation
- `scheduler.py` – time allocation, slots, breaks, timetable
- `data.json` – saved subjects, rules and last timetable

## Example Output (4 h/day, start 6:00 PM, on 01-10-2026)
Artificial Intelligence: Hard +3, Low prep +3, exam in 9 days +2 → **8 (High)**

| Date | Day | Time | Subject | Duration | Priority |
|------|-----|------|---------|----------|----------|
| 01-10-2026 | Thursday | 6:00 PM – 7:45 PM | Artificial Intelligence | 105 min | High |
| 01-10-2026 | Thursday | 7:45 PM – 8:00 PM | Break | 15 min | - |
| 01-10-2026 | Thursday | 8:00 PM – 9:15 PM | Mathematics | 75 min | Medium |
| 01-10-2026 | Thursday | 9:15 PM – 9:30 PM | Break | 15 min | - |
| 01-10-2026 | Thursday | 9:30 PM – 10:30 PM | DBMS | 60 min | Low |
